package com.hotelMang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelMangementTests {

	@Test
	void contextLoads() {
	}

}
