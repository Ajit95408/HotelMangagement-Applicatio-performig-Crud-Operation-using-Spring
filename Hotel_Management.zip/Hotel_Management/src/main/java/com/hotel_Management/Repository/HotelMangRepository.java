package com.hotel_Management.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hotel_Management.entities.HotelMangEntity;

public interface HotelMangRepository extends JpaRepository<HotelMangEntity, Long> {


	Optional<HotelMangEntity> findByFirstNameAndId(String firstName,long id);
    public List<HotelMangEntity> findDeletedUserByDeleted(boolean True);
    public List<HotelMangEntity> findUnDeletedUserByDeleted(boolean False);

}
 