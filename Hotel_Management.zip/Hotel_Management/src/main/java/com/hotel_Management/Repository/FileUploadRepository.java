package com.hotel_Management.Repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.hotel_Management.entities.FileUpload;

public interface FileUploadRepository extends JpaRepository<FileUpload, Long> {
	
}
