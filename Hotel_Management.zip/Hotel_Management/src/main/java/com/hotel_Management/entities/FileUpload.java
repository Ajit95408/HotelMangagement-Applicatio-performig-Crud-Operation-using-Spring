package com.hotel_Management.entities;


import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "file_upload_details")
public class FileUpload {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "file_id")
	private long fileId;

	@Column(name = "file_name")
	private String fileName;
	
	@Column(name = "file_path")
	private String filePath;
	
	@Column(name = "file_type")
	private String fileType;

	@JsonIgnore
	@ManyToOne
	@JoinColumn
	private HotelMangEntity hotelMangEntity;

	public long getFileId() {
		return fileId;
	}

	public void setFileId(long fileId) {
		this.fileId = fileId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public HotelMangEntity getUser() {
		return hotelMangEntity;
	}

	public void setUser(HotelMangEntity hotelMangEntity) {
		this.hotelMangEntity = hotelMangEntity;
	}

	@Override
	public String toString() {
		return "FileUpload [fileId=" + fileId + ", fileName=" + fileName + ", filePath=" + filePath + ", fileType="
				+ fileType + "]";
	}

}
