package com.hotel_Management.entities;

public class AddressEntity {
	
	private String address;

}
