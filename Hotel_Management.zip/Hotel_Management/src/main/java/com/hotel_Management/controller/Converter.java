package com.hotel_Management.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RestController;

import com.Hotel_MangDto.HotelMangDto;
import com.hotel_Management.entities.HotelMangEntity;

@RestController
public class Converter {
	@Autowired
	ModelMapper mapper;
	public HotelMangDto entityToDto(HotelMangEntity Entity) {
	
	HotelMangDto dto = mapper.map(Entity, HotelMangDto.class);
	
	return dto;
}
	
   public List<HotelMangDto> entityToDto(List<HotelMangEntity> entity){
	   return entity.stream().map(x->entityToDto(x)).collect(Collectors.toList());
   }
	   public HotelMangEntity dtoToEntity(HotelMangDto dto) {
		   HotelMangEntity entity = mapper.map(dto, HotelMangEntity.class);
		   return entity;
	   }
	   public List<HotelMangEntity> dtoToEntity(List<HotelMangDto> dto){
		   
		   return dto.stream().map(x->dtoToEntity(x)).collect(Collectors.toList());
	   }
	   
   }