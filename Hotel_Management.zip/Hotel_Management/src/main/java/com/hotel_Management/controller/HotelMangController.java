package com.hotel_Management.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Hotel_MangDto.HotelMangDto;
import com.hotel_Management.entities.HotelMangEntity;
import com.hotel_Management.services.HotelMangService;


@RestController
public class HotelMangController {

	@Autowired
	private HotelMangService hotelMangService;
	@Autowired
	private ModelMapper modelmapper;
    @Autowired Converter converter;


	@PostMapping("/SaveUSer")
	public HotelMangEntity saveUSer(@RequestBody HotelMangDto hotelMangDto) {

		hotelMangService.saveUser(hotelMangDto);
		return converter.dtoToEntity(hotelMangDto);
	}

	@GetMapping("/GetAllUSer")
	public List<HotelMangEntity> getAllUSer(){
		return hotelMangService.getAllUser();
	}
	@GetMapping("/GetDeletedUSer")
	public List<HotelMangEntity> getDeletedUSer(){
		return hotelMangService.findListOfDeletedUser(true);
		}
	@GetMapping("/GetUnDeletedUser")
	public List<HotelMangEntity> getUnDeletedUSer(){
		return hotelMangService.findListOfUnDeletedUser(false);
		}
	@GetMapping("/getUserByNameAndId/{firstName}/{id}")
	public HotelMangEntity getUserByName(@PathVariable String firstName,@PathVariable long id) {
		return hotelMangService.getUserByNamAndId(firstName, id);

	}

	@PutMapping("/updateUserById/{id}")
	public String updateUserById(@PathVariable("id") long id, @RequestBody HotelMangDto hotelMangDto ){
		return hotelMangService.updateUserById(id, hotelMangDto);


	}

	@DeleteMapping("/deleteUseryId/{id}")
	public String deleteUserById(@PathVariable("id") long id) {
	return hotelMangService.deleteUserById(id);

}

	public HotelMangDto entityToDto(HotelMangEntity hotel) {
//		HotelMangDto dto = new HotelMangDto();
//		dto.setFirstName(hotel.getFirstName());
//		dto.setLastName(hotel.getLastName());
//		dto.setEmail(hotel.getEmail());
//		dto.setPhoneNo(hotel.getPhoneNo());
//		return hotel;
//		 
		ModelMapper mapper = new ModelMapper();
		HotelMangDto map = mapper.map(hotel, HotelMangDto.class );
	     return map;
}
	List<HotelMangDto> entityToDto(List<HotelMangEntity> hotel){
		return hotel.stream().map(x->entityToDto(x)).collect(Collectors.toList());
	}

}