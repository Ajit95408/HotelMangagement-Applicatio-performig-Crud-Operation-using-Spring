package com.hotel_Management.services;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Hotel_MangDto.HotelMangDto;
import com.hotel_Management.Repository.HotelMangRepository;
import com.hotel_Management.entities.HotelMangEntity;


@Service
public class HotelMangService {
	
	@Autowired
	private HotelMangRepository hotelMangRepository;
	@Autowired
	private ModelMapper mapper;

	public HotelMangEntity saveUser(HotelMangDto hotelMangDto) {
	
		HotelMangEntity hotel = mapper.map(hotelMangDto, HotelMangEntity.class);
	   
       return hotelMangRepository.save(hotel);
	}
	
	public  List<HotelMangEntity> getAllUser(){
		return hotelMangRepository.findAll();
	}
	public HotelMangEntity getUserByNamAndId(String firstName,long id) {
		if(firstName != null && id != 0 ) {
		 return hotelMangRepository.findByFirstNameAndId(firstName, id).orElse(null);
	}else
		System.out.println("usern not found");
		return null;

	}
	public String deleteUserById(long id) {
		 hotelMangRepository.deleteById(id);
		 return "User Removed Successfully:-"+id;
		
	}
	public String updateUserById(long id, HotelMangDto hotelDto){
		Optional<HotelMangEntity> hotelentity = hotelMangRepository.findById(id);
		
	  if(hotelentity.isPresent()) {
		 HotelMangEntity entity = hotelentity.get();
		 entity.setId(id);
		 entity=mapper.map(entity, HotelMangEntity.class);
		
		  hotelMangRepository.save(entity);
	  }
	return "successfully Updated:-"+id;	
	}

 public List<HotelMangEntity> findListOfDeletedUser(boolean True) {
	 return hotelMangRepository.findDeletedUserByDeleted(true);
 }
 public List<HotelMangEntity> findListOfUnDeletedUser(boolean False) {
	 return hotelMangRepository.findUnDeletedUserByDeleted(false);
 }
}


